public enum PieceColor {
    White,Black;

    public String toString(){
        switch (this){
            case Black: return "Black";
            case White: return "White";
            default: return "";
        }
    }
}
