
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<ChessPiece> pieces=new ArrayList<>();
        ArrayList<ChessPiece> piece1 = new ArrayList<>();
          //add Top of the Chess Pieces(Black)

        //List of Black Pieces
        PiecePosition rook1B = new PiecePosition(0,0);
        PiecePosition knight1B = new PiecePosition(0,1);
        PiecePosition bishop1B = new PiecePosition(0,2);
        PiecePosition queenB = new PiecePosition(0,3);
        PiecePosition kingB = new PiecePosition(0,4);
        PiecePosition bishop2B = new PiecePosition(0,5);
        PiecePosition knight2B = new PiecePosition(0,6);
        PiecePosition rook2B = new PiecePosition(0,7);

        PiecePosition pawn1B = new PiecePosition(1,0);
        PiecePosition pawn2B = new PiecePosition(1,1);
        PiecePosition pawn3B = new PiecePosition(1,2);
        PiecePosition pawn4B = new PiecePosition(1,3);
        PiecePosition pawn5B = new PiecePosition(1,4);
        PiecePosition pawn6B = new PiecePosition(1,5);
        PiecePosition pawn7B = new PiecePosition(1,6);
        PiecePosition pawn8B = new PiecePosition(1,7);

        Rook Rook1B = new Rook(rook1B,PieceColor.Black);
        Knight Knight1B = new Knight(knight1B,PieceColor.Black);
        Bishop Bishop1B = new Bishop(bishop1B,PieceColor.Black);
        Queen QueenB = new Queen(queenB,PieceColor.Black);
        King KingB = new King(kingB,PieceColor.Black);
        Bishop Bishop2B = new Bishop(bishop2B,PieceColor.Black);
        Knight Knight2B = new Knight(knight2B,PieceColor.Black);
        Rook Rook2B = new Rook(rook2B,PieceColor.Black);

        Pawn Pawn1B=new Pawn(pawn1B,PieceColor.Black);
        Pawn Pawn2B=new Pawn(pawn2B,PieceColor.Black);
        Pawn Pawn3B=new Pawn(pawn3B,PieceColor.Black);
        Pawn Pawn4B=new Pawn(pawn4B,PieceColor.Black);
        Pawn Pawn5B=new Pawn(pawn5B,PieceColor.Black);
        Pawn Pawn6B=new Pawn(pawn6B,PieceColor.Black);
        Pawn Pawn7B=new Pawn(pawn7B,PieceColor.Black);
        Pawn Pawn8B=new Pawn(pawn8B,PieceColor.Black);
        //Add Black Pieces
        pieces.add(Rook1B);
        pieces.add(Knight1B);
        pieces.add(Bishop1B);
        pieces.add(QueenB);
        pieces.add(KingB);
        pieces.add(Bishop2B);
        pieces.add(Knight2B);
        pieces.add(Rook2B);

        pieces.add(Pawn1B);
        pieces.add(Pawn2B);
        pieces.add(Pawn3B);
        pieces.add(Pawn4B);
        pieces.add(Pawn5B);
        pieces.add(Pawn6B);
        pieces.add(Pawn7B);
        pieces.add(Pawn8B);
        //List of White Pieces
        PiecePosition pawn1W = new PiecePosition(6,0);
        PiecePosition pawn2W = new PiecePosition(6,1);
        PiecePosition pawn3W = new PiecePosition(6,2);
        PiecePosition pawn4W = new PiecePosition(6,3);
        PiecePosition pawn5W = new PiecePosition(6,4);
        PiecePosition pawn6W = new PiecePosition(6,5);
        PiecePosition pawn7W = new PiecePosition(6,6);
        PiecePosition pawn8W = new PiecePosition(6,7);

        PiecePosition rook1W = new PiecePosition(7,0);
        PiecePosition knight1W = new PiecePosition(7,1);
        PiecePosition bishop1W = new PiecePosition(7,2);
        PiecePosition queenW = new PiecePosition(7,3);
        PiecePosition kingW = new PiecePosition(7,4);
        PiecePosition bishop2W = new PiecePosition(7,5);
        PiecePosition knight2W = new PiecePosition(7,6);
        PiecePosition rook2W = new PiecePosition(7,7);

        Pawn Pawn1W=new Pawn(pawn1W,PieceColor.White);
        Pawn Pawn2W=new Pawn(pawn2W,PieceColor.White);
        Pawn Pawn3W=new Pawn(pawn3W,PieceColor.White);
        Pawn Pawn4W=new Pawn(pawn4W,PieceColor.White);
        Pawn Pawn5W=new Pawn(pawn5W,PieceColor.White);
        Pawn Pawn6W=new Pawn(pawn6W,PieceColor.White);
        Pawn Pawn7W=new Pawn(pawn7W,PieceColor.White);
        Pawn Pawn8W=new Pawn(pawn8W,PieceColor.White);

        Rook Rook1W = new Rook(rook1W,PieceColor.White);
        Knight Knight1W = new Knight(knight1W,PieceColor.White);
        Bishop Bishop1W = new Bishop(bishop1W,PieceColor.White);
        Queen QueenW = new Queen(queenW,PieceColor.White);
        King KingW = new King(kingW,PieceColor.White);
        Bishop Bishop2W = new Bishop(bishop2W,PieceColor.White);
        Knight Knight2W = new Knight(knight2W,PieceColor.White);
        Rook Rook2W = new Rook(rook2W,PieceColor.White);
        //Add White Pieces
        pieces.add(Pawn1W);
        pieces.add(Pawn2W);
        pieces.add(Pawn3W);
        pieces.add(Pawn4W);
        pieces.add(Pawn5W);
        pieces.add(Pawn6W);
        pieces.add(Pawn7W);
        pieces.add(Pawn8W);

        pieces.add(Rook1W);
        pieces.add(Knight1W);
        pieces.add(Bishop1W);
        pieces.add(QueenW);
        pieces.add(KingW);
        pieces.add(Bishop2W);
        pieces.add(Knight2W);
        pieces.add(Rook2W);





        ChessBoard cb =new ChessBoard(pieces);
        ChessBoard cb1=new ChessBoard(pieces);

        System.out.println("\033[1;31m                                                CLONE  \033[0;0m ");
        System.out.println("*****************************************************************************************************************");
        System.out.print("Clone of Chessboard :");
        System.out.println(cb.clone());
        System.out.println("*****************************************************************************************************************");
        System.out.println();
        System.out.println("\033[1;31m                                                CLONE  \033[0;0m ");
        System.out.println("*****************************************************************************************************************");
        System.out.println("Clone of Pawn :\n"+Pawn1W.clone());
        System.out.println("*****************************************************************************************************************");
        System.out.println("\n \n \n");
        System.out.print("ChessBoards are equals? ");
        System.out.println("("+(cb.equals(cb1))+")");

        System.out.println(cb.toString());

        System.out.println(cb.move(knight1W,new PiecePosition(5,2)));
        System.out.println(cb.move(pawn4B,new PiecePosition(2,3)));
        System.out.println(cb.move(pawn5W,new PiecePosition(5,4)));
        System.out.println(cb.move(pawn4B,new PiecePosition(3,3)));
        System.out.println(cb.isAttacked(pawn4B,PieceColor.Black));
        System.out.println(cb.move(knight1W,pawn4B));
        System.out.println("Get piece: "+cb.getPiece(pawn5W));

        System.out.println(cb.toString());

        //You need paper and pencil for draw chessboard,because I did not draw a chessboard, you should follow row and col(I am sorry)
        System.out.print("\033[1;31m POSSİBİLİTY OF MOVİNG : \033[0;0m ");
        System.out.print("\033[1;31m"+cb.mobility(PieceColor.White)+"\033[0;0m ");



    }
}
