public abstract class ChessPiece {
    PiecePosition position;
    PieceColor color;

    public ChessPiece(PiecePosition position, PieceColor color) {
        this.position = position;
        this.color = color;
    }

    abstract boolean canMove(PiecePosition target);
    abstract boolean canAttack(PiecePosition enemy_position);
    abstract boolean isInside(PiecePosition target);

}
