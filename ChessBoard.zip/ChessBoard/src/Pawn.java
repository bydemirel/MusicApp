public class Pawn extends ChessPiece {

    public Pawn(PiecePosition position,PieceColor color) {
        super(position,color);
    }
    public Pawn(Pawn other){
        super(other.position,other.color);
        super.position.row=other.position.row;
        super.position.col=other.position.col;
        super.color=other.color;
    }

    @Override
    boolean canMove(PiecePosition target) {
        if(color==PieceColor.Black) {
            if ((isInside(target))&&((position.col == target.col) && ((Math.abs(position.row - target.row) == 1))&&(position.row<target.row)))
                return true;
        }
        else if(color==PieceColor.White){
            if((isInside(target))&&((position.col == target.col) && (Math.abs(position.row - target.row) == 1)&&(position.row>target.row)))
            return true;
        }
        return false;
    }

    @Override
    boolean canAttack(PiecePosition enemy_position) {
        if(color==PieceColor.Black) {
            if ((isInside(enemy_position))&&((Math.abs(position.col-enemy_position.col)==1)&&(Math.abs(position.row - enemy_position.row) == 1)&&(position.row<enemy_position.row)))
                return true;
        }
        else if(color==PieceColor.White){
            if((isInside(enemy_position))&&((Math.abs(position.col - enemy_position.col)==1) &&(Math.abs(position.row - enemy_position.row) == 1)&&(position.row>enemy_position.row)))
                return true;
        }

        return false;

    }

    @Override
    boolean isInside(PiecePosition target) {
        if((target.row>=0 && target.row<8)&&(target.col>=0 && target.col<8))
            return true;
        else return false;
    }

    public Pawn clone(){
        return new Pawn(this);
    }
    public String toString(){
          return color+" Pawn["+position.row+","+position.col+"]";
    }
}
