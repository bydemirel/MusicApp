public class Bishop extends ChessPiece {

    public Bishop(PiecePosition position,PieceColor color) {
        super(position,color);
    }
    public Bishop(Bishop other){
        super(other.position,other.color);
        super.position.row=other.position.row;
        super.position.col=other.position.col;
        super.color=other.color;
    }
    @Override
    boolean canMove(PiecePosition target)
    {
        if((isInside(target))&&((Math.abs(position.row-target.row))==(Math.abs(position.col-target.col))))
            return true;
        else return false;
    }

    @Override
    boolean canAttack(PiecePosition enemy_position) {
        return canMove(enemy_position);
    }
    @Override
    boolean isInside(PiecePosition target) {
        if((target.row>=0 && target.row<8)&&(target.col>=0 && target.col<8))
            return true;
        else return false;
    }


    public Bishop clone(){
        return new Bishop(this);
    }
    public String toString(){
 return color+" Bishop["+position.row+","+position.col+"]";
    }
}
