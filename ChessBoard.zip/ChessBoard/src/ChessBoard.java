import java.util.ArrayList;

public class ChessBoard {
    ArrayList<ChessPiece> piece_list;

    public ChessBoard(ArrayList<ChessPiece> piece_list) {
        this.piece_list = piece_list;
    }

    public ChessBoard(ChessBoard other){
        piece_list=other.piece_list;
        for (int i = 0; i <piece_list.size() ; i++) {
            piece_list.get(i).position.row=other.piece_list.get(i).position.row;
            piece_list.get(i).position.col=other.piece_list.get(i).position.col;
        }
    }
    public ChessBoard clone(){
         return new ChessBoard(this);
    }

    public String toString(){
          int counter=0;
        for (int row = 0; row <4 ; row++) {
            System.out.println();
            if(row==2)
                System.out.println("********** VS **********");
            for (int col = 0; col <8 ; col++) {
                System.out.print(piece_list.get(counter));
                counter++;
            }
        }

       return "";
    }

    public ChessPiece getPiece(PiecePosition pos){
        for (int i = 0; i <piece_list.size() ; i++) {
            if((piece_list.get(i).position.row==pos.row)&&(piece_list.get(i).position.col==pos.col))
                return piece_list.get(i);
        }

        return null;
    }
    public boolean equals(ChessBoard other){
        for (int i = 0; i <piece_list.size() ; i++) {
            if((piece_list.get(i).position.row!=other.piece_list.get(i).position.row)||(piece_list.get(i).position.col!=other.piece_list.get(i).position.col))
                return false;
        }
        return true;
    }
    public boolean isAttacked(PiecePosition pos,PieceColor color){
        for (int i = 0; i <piece_list.size() ; i++) {
            if((isTherePiece(pos))&&(isOpen(piece_list.get(i).position,pos))&&!(piece_list.get(i).color.equals(color))&&(piece_list.get(i).canAttack(pos))){
                System.out.print(getPiece(piece_list.get(i).position)+"Attacked "+getPiece(pos)+" ");
                return true;
            }

        }
        return false;
    }
    private boolean isTherePiece(PiecePosition pos){
        if(getPiece(pos)!=null)
            return true;

        else return false;
    }


    public boolean move(PiecePosition from,PiecePosition target){
         if(((isEmpty(target))||(isTherePiece(target)&&(!getPiece(from).color.equals(getPiece(target).color))))&&(isOpen(from,target))&&(getPiece(from).canMove(target))){
             System.out.print(getPiece(from)+"Moving "+target+" ");
             getPiece(from).position.setRow(target.row);
             getPiece(from).position.setCol(target.col);
             return true;
         }
         else return false;
    }

    private boolean isMove(ChessPiece piece,PiecePosition pos){
        if(((isEmpty(pos))||(isTherePiece(pos)&&(!piece.color.equals(getPiece(pos).color))))&&(piece.canMove(pos))&&(isOpen(piece.position,pos)))
            return true;

        else return false;
    }


    private boolean isEmpty(PiecePosition target) {
        if(!(isTherePiece(target)))
            return true;

        else return false;
    }

    private boolean isOpen(PiecePosition pos1,PiecePosition pos2) {
        if(pos1.row==pos2.row){
            if(pos1.col<pos2.col){
                for (int i = pos1.col+1; i <pos2.col ; i++) {
                    if((isTherePiece(new PiecePosition(pos1.row,i))))
                        return false;
            }
                return true;

            }
            if(pos1.col>pos2.col){
                for (int i = pos1.col-1; i >pos2.col; i--) {
                    if((isTherePiece(new PiecePosition(pos1.row,i))))
                        return false;
                }
                return true;
            }
        }
        if(pos1.col==pos2.col){
            if(pos1.row<pos2.row){
                for (int i= pos1.row+1; i<pos2.row; i++) {
                    if((isTherePiece(new PiecePosition(i,pos1.col))))
                        return false;
                }
                return true;
            }
            if(pos1.row>pos2.row){
                for (int i = pos1.row-1; i >pos2.row ; i--) {
                    if((isTherePiece(new PiecePosition(i,pos1.col))))
                        return false;
                }
                return true;
            }
        }
        if(Math.abs(pos1.row-pos2.row)==Math.abs(pos1.col-pos2.col)){
            //sağ üst çarpraz
            if((pos1.row>pos2.row)&&(pos1.col<pos2.col)){
                for (int i = 0; i <Math.abs(pos1.row-pos2.row); i++) {
                    int row=pos1.row-1;
                    int col=pos1.col+1;
                    if(isTherePiece(new PiecePosition(row,col)))
                        return false;
                }
                return true;
            }
            //sol üst çarpraz
            if((pos1.row>pos2.row)&&(pos1.col>pos2.col)){
               for (int i = 0; i <Math.abs(pos1.row-pos2.row) ; i++) {
                    int row=pos1.row-1;
                    int col=pos1.col-1;
                    if(isTherePiece(new PiecePosition(row,col)))
                        return false;

                }
                return true;
            }
            //sağ alt çarpraz
            if((pos1.row<pos2.row)&&(pos1.col<pos2.col)){
                for (int i = 0; i <Math.abs(pos1.row-pos2.row); i++) {
                    int row=pos1.row+1;
                    int col=pos1.col+1;
                    if(isTherePiece(new PiecePosition(row,col)))
                        return false;
                }
                return true;
            }
            //sol alt çarpraz
            if((pos1.row<pos2.row)&&(pos1.col>pos2.col)){
                for (int i = 0; i <Math.abs(pos1.row-pos2.row) ; i++) {
                    int row=pos1.row+1;
                    int col=pos1.col-1;
                    if(isTherePiece(new PiecePosition(row,col)))
                        return false;
                }
                return true;
            }
        }
        return true;
    }




    public int mobility(PieceColor color){
        int sum=0;
        for (int i = 0; i <piece_list.size() ; i++) {
            if(piece_list.get(i).color.equals(color))
                sum += numberOfPossibility(piece_list.get(i));
        }
           return sum;
    }
    public int numberOfPossibility(ChessPiece piece){
        int counter=0;
        for (int i = 0; i <8 ; i++) {
            for (int j = 0; j <8 ; j++) {
                PiecePosition pos=new PiecePosition(i,j);
                if(isMove(piece,pos))
                    counter++;
            }

        }
        return counter;
    }
}
