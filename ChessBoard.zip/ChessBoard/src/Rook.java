public class Rook extends ChessPiece {


    public Rook(PiecePosition position,PieceColor color) {
        super(position,color);
    }
    public Rook(Rook other){
        super(other.position,other.color);
        super.position.row=other.position.row;
        super.position.col=other.position.col;
        super.color=other.color;
    }
    @Override
    boolean canMove(PiecePosition target) {
        if((isInside(target))&&((position.row==target.row)||(position.col==target.col)))
            return true;
        else return false;
    }

    @Override
    boolean canAttack(PiecePosition enemy_position) {
        return canMove(enemy_position);
    }
    @Override
    boolean isInside(PiecePosition target) {
        if((target.row>=0 && target.row<8)&&(target.col>=0 && target.col<8))
            return true;
        else return false;
    }


    public Rook clone(){
        return new Rook(this);
    }
    public String toString(){
          return color+" Rook["+position.row+","+position.col+"]";
    }
}
